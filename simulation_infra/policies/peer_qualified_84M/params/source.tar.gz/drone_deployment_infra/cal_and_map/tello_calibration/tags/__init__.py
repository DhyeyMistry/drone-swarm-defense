"""AprilTag detection and pose."""
